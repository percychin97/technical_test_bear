import 'package:technical_test_bear/model/battle/board_grid.dart';
import 'package:technical_test_bear/model/battle/circle_item.dart';

BoardGrid boardGrid = BoardGrid.random(8, 8);

int chosenIndex = -1;