package com.example.technical_test_bear

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
